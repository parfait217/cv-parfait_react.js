 
# Initialisation de Pygame
pygame.init()

# Définition des couleu rs
red = (255,255,255)
BLACK = (0, 0, 0)
WHITE = (255, 0, 255)
red = (255,0,0)
green = (0,255,0)

# Taille de la fenêtre
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600

# Initialisation de la fenêtre
window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Collision Detection")

# Définition des carrés
player_size = 25
player_x = 0
player_y = 0
player_speed = 1

#obstacle 0

obstacle_x = 0
obstacle_y = 45
obstacle_width = 100
obstacle_height = 200
#obstacle 1
obstacle_x1 = 400
obstacle_y1 = 0
obstacle_width1 = 350
obstacle_height1 = 50
#obstacle2
obstacle_x2 = 0
obstacle_y2 = 285
obstacle_width2 = 300
obstacle_height2 = 5

#obstacle3
obstacle_x3 = 300
obstacle_y3 = 245
obstacle_width3 = 5
obstacle_height3 = 45

#obstacle4
obstacle_x4 = 150
obstacle_y4 = 45
obstacle_width4= 200
obstacle_height4 = 200

#obstacle5
obstacle_x5 = 0
obstacle_y5 = 337
obstacle_width5= 100
obstacle_height5 = 218

#obstacle6
obstacle_x6 = 150
obstacle_y6 = 337
obstacle_width6= 100
obstacle_height6 = 218

#obstacle7
obstacle_x7 = 400
obstacle_y7 = 45
obstacle_width7= 6
obstacle_height7 = 292

#obstacle8
obstacle_x8 = 250
obstacle_y8 = 337
obstacle_width8= 156
obstacle_height8 = 6

#obstacle9
obstacle_x9 = 300
obstacle_y9 = 390
obstacle_width9= 110
obstacle_height9 = 210

#obstacle10
obstacle_x10 = 458
obstacle_y10 = 290
obstacle_width10= 375
obstacle_height10 = 259

#obstacle10
obstacle_x10 = 458
obstacle_y10 = 287
obstacle_width10= 375
obstacle_height10 = 259

 #obstacle11
obstacle_x11 = 458
obstacle_y11 = 97
obstacle_width11= 375
obstacle_height11 = 147
 
image = pygame.image.load("pacman.png")
image.convert()
# Boucle principale du jeu
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_UP]:
        player_y -= player_speed
        window.blit(image,[player_x , player_y])
    if keys[pygame.K_DOWN]:
        player_y += player_speed
        window.blit(image,[player_x , player_y])
    if keys[pygame.K_LEFT]:
        player_x -= player_speed
        window.blit(image,[player_x , player_y])
    if keys[pygame.K_RIGHT]:
        player_x += player_speed
        window.blit(image,[player_x , player_y])

    # Vérifier les collisions avec le carré immobile
    if player_x < obstacle_x + obstacle_width and player_x + player_size > obstacle_x and player_y < obstacle_y + obstacle_height and player_y + player_size > obstacle_y:
        # Collision détectée, annuler le mouvement
        if keys[pygame.K_UP]:
            player_y += player_speed
        if keys[pygame.K_DOWN]:
            player_y -= player_speed
        if keys[pygame.K_LEFT]:
            player_x += player_speed
        if keys[pygame.K_RIGHT]:
            player_x -= player_speed
    # verifier les collisins avec le carre 1 :
    if player_x < obstacle_x1 + obstacle_width1 and player_x + player_size > obstacle_x1 and player_y < obstacle_y1 + obstacle_height1 and player_y + player_size > obstacle_y1:
        # Collision détectée, annuler le mouvement
        if keys[pygame.K_UP]:
            player_y += player_speed
        if keys[pygame.K_DOWN]:
            player_y -= player_speed
        if keys[pygame.K_LEFT]:
            player_x += player_speed
        if keys[pygame.K_RIGHT]:
            player_x -= player_speed


      # verifier les collisins avec le carre 2 :
    if player_x < obstacle_x2 + obstacle_width2 and player_x + player_size > obstacle_x2 and player_y < obstacle_y2 + obstacle_height2 and player_y + player_size > obstacle_y2:
        # Collision détectée, annuler le mouvement
        if keys[pygame.K_UP]:
            player_y += player_speed
        if keys[pygame.K_DOWN]:
            player_y -= player_speed
        if keys[pygame.K_LEFT]:
            player_x += player_speed
        if keys[pygame.K_RIGHT]:
            player_x -= player_speed

       # verifier les collisins avec le carre 3 :
    if player_x < obstacle_x3 + obstacle_width3 and player_x + player_size > obstacle_x3 and player_y < obstacle_y3 + obstacle_height3 and player_y + player_size > obstacle_y3:
        # Collision détectée, annuler le mouvement
        if keys[pygame.K_UP]:
            player_y += player_speed
        if keys[pygame.K_DOWN]:
            player_y -= player_speed
        if keys[pygame.K_LEFT]:
            player_x += player_speed
        if keys[pygame.K_RIGHT]:
            player_x -= player_speed

    # verifier les collisins avec le carre 4 :
    if player_x < obstacle_x4 + obstacle_width4 and player_x + player_size > obstacle_x4 and player_y < obstacle_y4 + obstacle_height4 and player_y + player_size > obstacle_y4:
        # Collision détectée, annuler le mouvement
        if keys[pygame.K_UP]:
            player_y += player_speed
        if keys[pygame.K_DOWN]:
            player_y -= player_speed
        if keys[pygame.K_LEFT]:
            player_x += player_speed
        if keys[pygame.K_RIGHT]:
            player_x -= player_speed

    # verifier les collisins avec le carre 5 :
    if player_x < obstacle_x5 + obstacle_width5 and player_x + player_size > obstacle_x5 and player_y < obstacle_y5 + obstacle_height5 and player_y + player_size > obstacle_y5:
        # Collision détectée, annuler le mouvement
        if keys[pygame.K_UP]:
            player_y += player_speed
        if keys[pygame.K_DOWN]:
            player_y -= player_speed
        if keys[pygame.K_LEFT]:
            player_x += player_speed
        if keys[pygame.K_RIGHT]:
            player_x -= player_speed

    # verifier les collisins avec le carre 6 :
    if player_x < obstacle_x6 + obstacle_width6 and player_x + player_size > obstacle_x6 and player_y < obstacle_y6 + obstacle_height6 and player_y + player_size > obstacle_y6:
        # Collision détectée, annuler le mouvement
        if keys[pygame.K_UP]:
            player_y += player_speed
        if keys[pygame.K_DOWN]:
            player_y -= player_speed
        if keys[pygame.K_LEFT]:
            player_x += player_speed
        if keys[pygame.K_RIGHT]:
            player_x -= player_speed

    # verifier les collisins avec le carre 7 :
    if player_x < obstacle_x7 + obstacle_width7 and player_x + player_size > obstacle_x7 and player_y < obstacle_y7 + obstacle_height7 and player_y + player_size > obstacle_y7:
        # Collision détectée, annuler le mouvement
        if keys[pygame.K_UP]:
            player_y += player_speed
        if keys[pygame.K_DOWN]:
            player_y -= player_speed
        if keys[pygame.K_LEFT]:
            player_x += player_speed
        if keys[pygame.K_RIGHT]:
            player_x -= player_speed

    # verifier les collisins avec le carre 8 :
    if player_x < obstacle_x8 + obstacle_width8 and player_x + player_size > obstacle_x8 and player_y < obstacle_y8 + obstacle_height8 and player_y + player_size > obstacle_y8:
        # Collision détectée, annuler le mouvement
        if keys[pygame.K_UP]:
            player_y += player_speed
        if keys[pygame.K_DOWN]:
            player_y -= player_speed
        if keys[pygame.K_LEFT]:
            player_x += player_speed
        if keys[pygame.K_RIGHT]:
            player_x -= player_speed

    # verifier les collisins avec le carre 9 :
    if player_x < obstacle_x9 + obstacle_width9 and player_x + player_size > obstacle_x9 and player_y < obstacle_y9 + obstacle_height9 and player_y + player_size > obstacle_y9 :
        # Collision détectée, annuler le mouvement
        if keys[pygame.K_UP]:
            player_y += player_speed
        if keys[pygame.K_DOWN]:
            player_y -= player_speed
        if keys[pygame.K_LEFT]:
            player_x += player_speed
        if keys[pygame.K_RIGHT]:
            player_x -= player_speed

    # verifier les collisins avec le carre 10 :
    if player_x < obstacle_x10 + obstacle_width10 and player_x + player_size > obstacle_x10 and player_y < obstacle_y10 + obstacle_height10 and player_y + player_size > obstacle_y10 :
        # Collision détectée, annuler le mouvement
        if keys[pygame.K_UP]:
            player_y += player_speed
        if keys[pygame.K_DOWN]:
            player_y -= player_speed
        if keys[pygame.K_LEFT]:
            player_x += player_speed
        if keys[pygame.K_RIGHT]:
            player_x -= player_speed

    # verifier les collisins avec le carre 11 :
    if player_x < obstacle_x11 + obstacle_width11 and player_x + player_size > obstacle_x11 and player_y < obstacle_y11 + obstacle_height11 and player_y + player_size > obstacle_y11 :
        # Collision détectée, annuler le mouvement
        if keys[pygame.K_UP]:
            player_y += player_speed
        if keys[pygame.K_DOWN]:
            player_y -= player_speed
        if keys[pygame.K_LEFT]:
            player_x += player_speed
        if keys[pygame.K_RIGHT]:
            player_x -= player_speed


	# collision avec la largeur et la hauteur de la fenetre 
	
	# collision avec la largeur en haut
    if player_y < 0 :
    	player_y = 0
        
        # collision avec la largeur en bas
        
    if  player_y + player_size >  WINDOW_HEIGHT : 		
        if keys[pygame.K_DOWN]:
            player_y -= player_speed 
            
        # troixieme entree	
        	
    if  player_x <= -player_speed and player_y >= 246 and player_y <= 365 :   	
    	player_x= WINDOW_WIDTH-player_speed	
    	player_y = 255
    	
       #  troixieme sortie
       
    if player_x >= WINDOW_WIDTH and player_y >= 220 and player_y <= 400 :
    	player_x = 0
    	player_y = 255	
    	
    	# deuxieme sortie
    	
    if player_x >= WINDOW_WIDTH and player_y >=500 and player_y <= WINDOW_HEIGHT :
    	player_x = 0
    	player_y = WINDOW_HEIGHT - player_size
    	
        # premier entree
    if  player_x < -player_speed  :
        player_x = WINDOW_WIDTH
        
        # premiere sortie
    if player_x > WINDOW_WIDTH :
    	player_x = 0
    	player_y = 0
    # Dessiner les carrés et rafraîchir l'écran
    window.fill(red)
    #pygame.draw.rect(window, green, (player_x, player_y, player_size, player_size))
    window.blit(image,[player_x , player_y])
    pygame.draw.rect(window, WHITE, (obstacle_x, obstacle_y, obstacle_width, obstacle_height))
    pygame.draw.rect(window, WHITE, (obstacle_x1, obstacle_y1, obstacle_width1, obstacle_height1))
    pygame.draw.rect(window, WHITE, (obstacle_x2, obstacle_y2, obstacle_width2, obstacle_height2))
    pygame.draw.rect(window, WHITE, (obstacle_x3, obstacle_y3, obstacle_width3, obstacle_height3))
    pygame.draw.rect(window, WHITE, (obstacle_x4, obstacle_y4, obstacle_width4, obstacle_height4))
    pygame.draw.rect(window, WHITE, (obstacle_x5, obstacle_y5, obstacle_width5, obstacle_height5))
    pygame.draw.rect(window, WHITE, (obstacle_x6, obstacle_y6, obstacle_width6, obstacle_height6))
    pygame.draw.rect(window, WHITE, (obstacle_x7, obstacle_y7, obstacle_width7, obstacle_height7))
    pygame.draw.rect(window, WHITE, (obstacle_x8, obstacle_y8, obstacle_width8, obstacle_height8))
    pygame.draw.rect(window, WHITE, (obstacle_x9, obstacle_y9, obstacle_width9, obstacle_height9))
    pygame.draw.rect(window, WHITE, (obstacle_x10, obstacle_y10, obstacle_width10, obstacle_height10))
    pygame.draw.rect(window, WHITE, (obstacle_x11, obstacle_y11, obstacle_width11, obstacle_height11))
    pygame.display.flip()

pygame.quit()
sys.exit()
