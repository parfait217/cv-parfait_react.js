
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include"fonction.h"
#include <string.h>

typedef struct {
    int id;
    char nom[50];
    int quantite;
    float prix;    
    char nature[50];
	int jour;
	int mois;
	int annee;
    int min;
    int max;
}Produit;


int main()
{	int nbre =0;
	Produit stock[10000];
	printf("inserer les produits \n");
	 inserer_produit(stock, &nbre);
	 printf("voici tous les produits \n");
	 afficher_stock(stock, nbre);
	 return 0;

}
