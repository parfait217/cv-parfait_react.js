#ifdef FONTION_H
#define FONTION_H

void inserer_produit(Produit stock[], int *nbre);
void retirer_Produit(Produit stock[], int *nbre);
void afficher_stock(Produit stock[], int nbre);
void gerer_commande(Produit stock[], int nbre);
void peremption(Produit stock[],int nbre);

#endif
