
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include"fonction.h"
#include <string.h>

typedef struct {
    char id[88];
    char nom[50];
    int quantite;
    float prix;    
    char nature[50];
	int jour;
	int mois;
	int annee;
    int min;
    int max;
}Produit;

// FONCTION POUR FOURNIR AUTOMATIQUEMENT LES IDENTIFIENT DES PRODUITS


char *generer_id()
{


	char *identifient;
	identifient = malloc(5*sizeof(char));
	srand(time(NULL));
	for(int i = 0; i<4;i++)
	{
		identifient[i] = rand() % 10 + '0' ;
	}
	identifient[4] = '\0';
	
	return identifient;
}


// FONCTION POUR INSERER UN PRODUIT 

void inserer_produit(Produit stock[], int *nbre)
{	*nbre = 0;
	int n;
	FILE *fichier = NULL;
        fichier = fopen("projet.txt", "a");
        printf("entrer le nombre de produit a ajouter :\n");
        scanf("%d",&n);
	printf("entrer les informations du produit a inserer \n");
        char* id;
        for(int i =0 ; i<n ; i++)
        {
        
        
               id = generer_id();
        	strcpy(stock[i].id , id);
       		printf("entrer le nom du produit \n");
       		scanf("%s",stock[i].nom);
       		printf("entrer la quantitee du produit \n");
       		scanf("%d",&stock[i].quantite);
       		printf("Enter le prix du produit: ");    
                scanf("%f", &stock[i].prix);   
                
                printf("Entree la date de peremption (jour, mois, annee):\n");
        	printf("Entrez le jour de peremption: ");
      	        scanf("%d",&stock[i].jour);
        	printf("Entrez le mois de peremption:");
        	scanf("%d",&stock[i].mois);
        	printf("Entrez l'annee de peremption:");
        	scanf("%d",&stock[i].annee);
        	printf("Entrez la quantite minimale du produit que l'entreprise devra toujours posseder: ");
        	scanf("%d", &stock[i].min);
        	printf("Entrez la quantite maximale du produit  que l'entreprise devra toujours posseder:");
	    	scanf("%d", &stock[i].max);
	    	fprintf(fichier,"%s\t\t  %s\t\t %d\t\t %.2f\t\t %d/%d%d\t\t %d\t\t %d\n " , stock->id, stock->nom,stock->quantite,stock->prix,stock->jour,stock->mois,stock->annee,stock->min,stock->max);
    		//stock[*nbre] = nouveauProduit;
   		(*nbre)++;
  	
       		
	}
	
	fclose(fichier);
	free(id);	

}

// FONCTION POUR AFFICHER TOUS LES PRODUITS A PARTIRE DU FICHIER 


void afficher_stock(Produit stock[], int nbre) {
    
           FILE *fichier = NULL;
           fichier = fopen("projet.txt", "r");

   if(fichier != NULL){
   //fichier = fopen("projet.txt", "r");

        printf("\n");
    while(!feof(fichier))
       		 {

        		fscanf(fichier,"%s\t%s\t%d\t\t%f\t%d/%d/%d\t\t%d\t\t\t%d\n", stock->id, stock->nom,&stock->quantite,&stock->prix, &stock->jour,&stock->mois,&stock->annee,&stock->min,&stock->max);
        		
      
       		 
printf("%s\t%s\t%d\t\t%f\t\t%d/%d/%d\t\t%d\t\t\t%d\n", stock->id, stock->nom,stock->quantite,stock->prix, stock->jour,stock->mois,stock->annee,stock->min,stock->max);
            		
        		


}
}
     fclose(fichier);
}

